# Interactive_3D_Earth


** Live Site Link: https://shuqi7.github.io/Interactive_3D_Earth/


* Interactive 3D Earth built based on Three.js and WebGL
* CSS-based 2D locations points to follow 3D Earth movement
* 3D projectiles to connect points
* Interactive sidebar to showcase specifc information
* Earth rotating to make points clicked always facing the user

## Screenshot:
![alt text](http://i64.tinypic.com/6p3mo2.png)
